###Plasmatic Isosurface

A 2 dimensional plasma simulation running on the GPU, written in [GLSL](http://en.wikipedia.org/wiki/GLSL) and [CoffeeScript](http://coffeescript.org/) and rendered with [WebGL](http://caniuse.com/webgl).

[See it in action!](http://soulwire.github.com/Plasmatic-Isosurface/)

Uses [sketch.js](https://github.com/soulwire/sketch.js) and [dat.GUI](http://code.google.com/p/dat-gui/)